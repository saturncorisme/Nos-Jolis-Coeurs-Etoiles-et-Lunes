// src/pages/NewArchivePage.js
import { supabase, uploadArchivePhoto, reverseGeocode } from '../lib/supabase.js'
import { AppState, navigate } from '../main.js'

export async function renderNewArchivePage() {
  if (!AppState.user) { navigate('/login'); return '' }

  return `
    <div class="container-narrow" style="padding:3rem 1.5rem 5rem">
      <div style="text-align:center;margin-bottom:2.5rem">
        <div style="font-size:3rem;margin-bottom:.5rem">♡ ☆ ☽</div>
        <h1 style="font-style:italic">Nouvelle archive</h1>
        <p style="color:var(--ink-soft)">Racontez l'histoire d'une forme trouvée.</p>
      </div>

      <div class="card" style="padding:2rem">
        <div id="new-archive-error"   class="alert alert-error"   style="display:none"></div>
        <div id="new-archive-success" class="alert alert-success" style="display:none"></div>

        <form id="new-archive-form" novalidate>

          <!-- Photo -->
          <div class="form-group">
            <label>Photo *</label>
            <div class="photo-upload-zone" id="photo-drop-zone">
              <div id="photo-preview-wrap" style="display:none">
                <img id="photo-preview" alt="Aperçu" style="max-height:260px;max-width:100%;border-radius:var(--radius-sm);object-fit:contain">
                <button type="button" class="btn btn-ghost btn-sm" id="remove-photo" style="margin-top:.5rem">
                  Changer la photo
                </button>
              </div>
              <div id="photo-placeholder">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="color:var(--ink-soft);margin-bottom:.75rem"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                <p style="color:var(--ink-soft);margin:0 0 .75rem;font-size:.9rem">
                  Glissez une photo ou cliquez pour choisir
                </p>
                <p class="mono" style="font-size:.72rem">JPG, PNG, WEBP · Max 5 Mo</p>
              </div>
              <input type="file" id="photo-input" name="photo" accept="image/jpeg,image/png,image/webp"
                style="position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%">
            </div>
            <div id="photo-error" style="color:var(--err-color,#b00020);font-size:.82rem;margin-top:.3rem;display:none"></div>
          </div>

          <!-- Titre -->
          <div class="form-group">
            <label for="archive-title">Titre de la forme *</label>
            <input id="archive-title" name="title" type="text" class="form-input"
              placeholder="ex: Cœur de rouille, Étoile de bitume, Lune de carrelage…"
              maxlength="120" required>
            <p style="font-size:.78rem;color:var(--ink-soft);margin-top:.25rem;font-family:var(--fm)">
              Commencez par le type : Cœur, Étoile ou Lune
            </p>
          </div>

          <!-- Histoire -->
          <div class="form-group">
            <label for="archive-story">Histoire / Récit *</label>
            <textarea id="archive-story" name="story" class="form-textarea"
              placeholder="Où avez-vous trouvé cette forme ? Qu'est-ce qui vous a touché ? Quel moment était-ce ?…"
              rows="5" maxlength="2000" required></textarea>
            <p id="story-count" class="mono" style="text-align:right;margin-top:.2rem;font-size:.72rem">0 / 2000</p>
          </div>

          <!-- GPS -->
          <div class="form-group">
            <label>Localisation <span style="color:var(--ink-soft);font-weight:300">(optionnel)</span></label>
            <div style="display:flex;gap:.75rem;align-items:flex-start;flex-wrap:wrap">
              <div style="flex:1;min-width:120px">
                <input id="archive-lat" name="latitude" type="number" class="form-input"
                  placeholder="Latitude" step="any" min="-90" max="90">
              </div>
              <div style="flex:1;min-width:120px">
                <input id="archive-lng" name="longitude" type="number" class="form-input"
                  placeholder="Longitude" step="any" min="-180" max="180">
              </div>
              <button type="button" class="btn btn-ghost" id="gps-btn" title="Ma position actuelle">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                Ma position
              </button>
            </div>
            <div id="geocode-result" class="mono" style="font-size:.78rem;color:var(--ink-soft);margin-top:.4rem;display:none"></div>
          </div>

          <!-- Progress upload -->
          <div id="upload-progress" style="display:none;margin-bottom:1rem">
            <div style="height:4px;background:var(--rule);border-radius:99px;overflow:hidden">
              <div id="progress-bar" style="height:100%;background:var(--accent);width:0%;transition:width .3s;border-radius:99px"></div>
            </div>
            <p class="mono" style="font-size:.75rem;margin-top:.25rem;color:var(--ink-soft)" id="progress-label">
              Upload en cours…
            </p>
          </div>

          <div style="display:flex;gap:.75rem;flex-wrap:wrap">
            <button type="submit" class="btn btn-primary" id="submit-btn" style="flex:1;justify-content:center;min-width:160px">
              Archiver ♡
            </button>
            <a href="/my-archives" data-link class="btn btn-ghost">Annuler</a>
          </div>
        </form>
      </div>
    </div>

    <style>
    .photo-upload-zone {
      position: relative;
      border: 2px dashed var(--rule);
      border-radius: var(--radius);
      padding: 2rem;
      text-align: center;
      cursor: pointer;
      transition: border-color .15s, background .15s;
      min-height: 180px;
      display: flex; align-items: center; justify-content: center;
      flex-direction: column;
    }
    .photo-upload-zone:hover, .photo-upload-zone.drag-over {
      border-color: var(--accent);
      background: var(--bg-alt);
    }
    </style>
  `
}

// Handler attaché depuis main.js
window.NewArchiveHandlers = function() {
  const form       = document.getElementById('new-archive-form')
  const photoInput = document.getElementById('photo-input')
  const dropZone   = document.getElementById('photo-drop-zone')
  const errEl      = document.getElementById('new-archive-error')
  const photoErr   = document.getElementById('photo-error')
  let selectedFile = null

  if (!form) return

  // Compteur histoire
  document.getElementById('archive-story')?.addEventListener('input', e => {
    document.getElementById('story-count').textContent = `${e.target.value.length} / 2000`
  })

  // Drag & drop
  dropZone?.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over') })
  dropZone?.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'))
  dropZone?.addEventListener('drop', e => {
    e.preventDefault(); dropZone.classList.remove('drag-over')
    const file = e.dataTransfer?.files[0]
    if (file) handlePhotoSelect(file)
  })

  photoInput?.addEventListener('change', () => {
    if (photoInput.files[0]) handlePhotoSelect(photoInput.files[0])
  })

  document.getElementById('remove-photo')?.addEventListener('click', () => {
    selectedFile = null
    document.getElementById('photo-preview-wrap').style.display = 'none'
    document.getElementById('photo-placeholder').style.display  = ''
    photoInput.value = ''
  })

  function handlePhotoSelect(file) {
    photoErr.style.display = 'none'
    if (!['image/jpeg','image/png','image/webp'].includes(file.type)) {
      photoErr.textContent = 'Format non supporté. Utilisez JPG, PNG ou WEBP.'
      photoErr.style.display = 'block'; return
    }
    if (file.size > 5 * 1024 * 1024) {
      photoErr.textContent = 'Fichier trop lourd (max 5 Mo).'
      photoErr.style.display = 'block'; return
    }
    selectedFile = file
    const reader = new FileReader()
    reader.onload = e => {
      document.getElementById('photo-preview').src = e.target.result
      document.getElementById('photo-preview-wrap').style.display = ''
      document.getElementById('photo-placeholder').style.display  = 'none'
    }
    reader.readAsDataURL(file)
  }

  // GPS
  document.getElementById('gps-btn')?.addEventListener('click', () => {
    if (!navigator.geolocation) {
      errEl.textContent = 'Géolocalisation non supportée.'; errEl.style.display = 'block'; return
    }
    const btn = document.getElementById('gps-btn')
    btn.disabled = true; btn.textContent = 'Localisation…'
    navigator.geolocation.getCurrentPosition(async pos => {
      const lat = pos.coords.latitude, lng = pos.coords.longitude
      document.getElementById('archive-lat').value = lat.toFixed(6)
      document.getElementById('archive-lng').value = lng.toFixed(6)
      btn.disabled = false; btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg> Ma position`
      // Reverse geocode
      const geocodeEl = document.getElementById('geocode-result')
      geocodeEl.textContent = 'Identification de l\'adresse…'
      geocodeEl.style.display = 'block'
      const address = await reverseGeocode(lat, lng)
      geocodeEl.textContent = address ? `📍 ${address}` : `${lat.toFixed(5)}, ${lng.toFixed(5)}`
    }, () => {
      btn.disabled = false
      errEl.textContent = 'Impossible d\'obtenir la position. Vérifiez les permissions.'
      errEl.style.display = 'block'
    })
  })

  // Soumission
  form.addEventListener('submit', async e => {
    e.preventDefault()
    errEl.style.display = 'none'
    const title  = form.title.value.trim()
    const story  = form.story.value.trim()
    const lat    = parseFloat(form.latitude.value)  || null
    const lng    = parseFloat(form.longitude.value) || null
    const btn    = document.getElementById('submit-btn')

    if (!title) { errEl.textContent = 'Le titre est obligatoire.'; errEl.style.display = 'block'; return }
    if (!story) { errEl.textContent = 'L\'histoire est obligatoire.'; errEl.style.display = 'block'; return }

    btn.disabled = true; btn.textContent = 'Archivage…'

    let photoUrl = null
    if (selectedFile) {
      // Simuler progress
      const prog  = document.getElementById('upload-progress')
      const bar   = document.getElementById('progress-bar')
      const label = document.getElementById('progress-label')
      prog.style.display = 'block'
      bar.style.width = '30%'; label.textContent = 'Upload de la photo…'

      const { url, error: uploadError } = await uploadArchivePhoto(AppState.user.id, selectedFile)
      if (uploadError) {
        errEl.textContent = 'Erreur upload photo : ' + uploadError.message
        errEl.style.display = 'block'
        btn.disabled = false; btn.textContent = 'Archiver ♡'
        prog.style.display = 'none'; return
      }
      bar.style.width = '80%'; label.textContent = 'Enregistrement…'
      photoUrl = url
    }

    const { data, error } = await supabase.from('archives').insert({
      user_id:   AppState.user.id,
      title,
      story,
      latitude:  lat,
      longitude: lng,
      photo_url: photoUrl,
    }).select().single()

    if (error) {
      errEl.textContent = 'Erreur : ' + error.message
      errEl.style.display = 'block'
      btn.disabled = false; btn.textContent = 'Archiver ♡'
      document.getElementById('upload-progress').style.display = 'none'
      return
    }

    document.getElementById('progress-bar').style.width = '100%'
    document.getElementById('progress-label').textContent = 'Archivé !'

    setTimeout(() => navigate(`/a/${data.id}`), 600)
  })

  // data-link
  document.querySelectorAll('[data-link]').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault()
      const { navigate } = window.__appImports || {}
      import('../main.js').then(m => m.navigate(el.getAttribute('href')))
    })
  })
}
