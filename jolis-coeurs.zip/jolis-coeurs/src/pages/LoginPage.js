// src/pages/LoginPage.js
export async function renderLoginPage() {
  return `
    <div class="container-narrow" style="padding:4rem 1.5rem">
      <div style="text-align:center;margin-bottom:2.5rem">
        <div style="font-size:3rem;margin-bottom:.5rem">☽</div>
        <h1 style="font-style:italic">Bon retour</h1>
        <p style="color:var(--ink-soft)">Reconnectez-vous à votre archive.</p>
      </div>

      <div class="card" style="padding:2rem">
        <div id="login-error"  class="alert alert-error"   style="display:none"></div>
        <div id="login-success" class="alert alert-success" style="display:none"></div>

        <form id="login-form" novalidate>
          <div class="form-group">
            <label for="login-email">Adresse email</label>
            <input id="login-email" name="email" type="email" class="form-input"
              placeholder="votre@email.com" autocomplete="email" required>
          </div>
          <div class="form-group">
            <label for="login-password">Mot de passe</label>
            <input id="login-password" name="password" type="password" class="form-input"
              placeholder="••••••••" autocomplete="current-password" required>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:.5rem">
            Se connecter
          </button>
        </form>

        <div style="text-align:center;margin-top:1.25rem">
          <button id="forgot-link" class="btn btn-ghost btn-sm" style="font-size:.85rem">
            Mot de passe oublié ?
          </button>
        </div>
      </div>

      <p style="text-align:center;margin-top:1.5rem;color:var(--ink-soft);font-size:.9rem">
        Pas encore de compte ?
        <a href="/signup" data-link style="color:var(--accent)">Créer mon archive</a>
      </p>
    </div>
  `
}

// src/pages/SignupPage.js — exporté dans le même fichier pour la cohérence
export async function renderSignupPage() {
  return `
    <div class="container-narrow" style="padding:4rem 1.5rem">
      <div style="text-align:center;margin-bottom:2.5rem">
        <div style="font-size:3rem;margin-bottom:.5rem">♡</div>
        <h1 style="font-style:italic">Créer mon archive</h1>
        <p style="color:var(--ink-soft)">Commencez à collecter les formes du monde.</p>
      </div>

      <div class="card" style="padding:2rem">
        <div id="signup-error" class="alert alert-error" style="display:none"></div>

        <form id="signup-form" novalidate>
          <div class="form-group">
            <label for="signup-username">Pseudo <span style="color:var(--ink-soft);font-weight:300">(unique, dans l'URL)</span></label>
            <input id="signup-username" name="username" type="text" class="form-input"
              placeholder="ex: marie_archives" autocomplete="username"
              pattern="[a-zA-Z0-9_-]+" maxlength="32" required>
            <p style="font-size:.78rem;color:var(--ink-soft);margin-top:.3rem;font-family:var(--fm)">
              Lettres, chiffres, - et _ uniquement. Votre profil sera sur /u/votre-pseudo
            </p>
          </div>
          <div class="form-group">
            <label for="signup-display-name">Nom affiché</label>
            <input id="signup-display-name" name="display_name" type="text" class="form-input"
              placeholder="Marie Durand" autocomplete="name" maxlength="60">
          </div>
          <div class="form-group">
            <label for="signup-email">Adresse email</label>
            <input id="signup-email" name="email" type="email" class="form-input"
              placeholder="votre@email.com" autocomplete="email" required>
          </div>
          <div class="form-group">
            <label for="signup-password">Mot de passe <span style="color:var(--ink-soft);font-weight:300">(6 caractères min)</span></label>
            <input id="signup-password" name="password" type="password" class="form-input"
              placeholder="••••••••" autocomplete="new-password" minlength="6" required>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:.5rem">
            Créer mon compte
          </button>
        </form>
      </div>

      <p style="text-align:center;margin-top:1.5rem;color:var(--ink-soft);font-size:.9rem">
        Déjà un compte ?
        <a href="/login" data-link style="color:var(--accent)">Me connecter</a>
      </p>
    </div>
  `
}
