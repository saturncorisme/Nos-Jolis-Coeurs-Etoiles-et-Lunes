// src/pages/SettingsPage.js
import { supabase, uploadAvatar } from '../lib/supabase.js'
import { AppState, navigate, applyTheme, loadProfile } from '../main.js'

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
}

const FONT_OPTIONS = [
  {
    value: 'classic',
    label: 'Classique archive',
    desc:  'Playfair Display + Lora + IBM Plex Mono',
    preview: { title: 'Classique archive', sample: 'Une forme trouvée dans les rues…' }
  },
  {
    value: 'soft',
    label: 'Écriture douce',
    desc:  'Cormorant Garamond + Nunito + Caveat',
    preview: { title: 'Écriture douce', sample: 'Une forme trouvée dans les rues…' }
  },
  {
    value: 'modern',
    label: 'Minimal moderne',
    desc:  'DM Mono + Nunito + JetBrains Mono',
    preview: { title: 'Minimal moderne', sample: 'Une forme trouvée dans les rues…' }
  },
  {
    value: 'travel',
    label: 'Carnet de voyage',
    desc:  'DM Serif Display + Source Serif 4 + Courier Prime',
    preview: { title: 'Carnet de voyage', sample: 'Une forme trouvée dans les rues…' }
  },
]

const THEME_OPTIONS = [
  { value: 'cream',  label: 'Papier crémeux', emoji: '☽', color: '#fef9e8' },
  { value: 'sky',    label: 'Ciel pastel',    emoji: '☆', color: '#e8f4ff' },
  { value: 'bloom',  label: 'Fleur pastel',   emoji: '♡', color: '#fff0f8' },
]

export async function renderSettingsPage() {
  if (!AppState.user) { navigate('/login'); return '' }
  const profile = AppState.profile

  return `
    <div class="container-narrow" style="padding:3rem 1.5rem 5rem">
      <h1 style="font-style:italic;margin-bottom:.25rem">Réglages</h1>
      <p style="color:var(--ink-soft);margin-bottom:2.5rem">Personnalisez votre profil et votre archive.</p>

      <div id="settings-error"   class="alert alert-error"   style="display:none"></div>
      <div id="settings-success" class="alert alert-success" style="display:none"></div>

      <!-- ── Section Profil ── -->
      <section class="settings-section card" style="padding:1.75rem;margin-bottom:1.5rem">
        <h2 class="settings-section-title">Mon profil</h2>

        <!-- Avatar -->
        <div style="display:flex;align-items:center;gap:1.25rem;margin-bottom:1.5rem;flex-wrap:wrap">
          <div id="avatar-preview-wrap">
            ${profile?.avatar_url
              ? `<img src="${esc(profile.avatar_url)}" alt="" class="avatar" id="avatar-img" style="width:72px;height:72px">`
              : `<div class="avatar-placeholder" id="avatar-ph" style="width:72px;height:72px;font-size:1.8rem">
                  ${(profile?.display_name || profile?.username || '?')[0]?.toUpperCase()}
                </div>`
            }
          </div>
          <div>
            <label class="btn btn-ghost btn-sm" for="avatar-input" style="cursor:pointer;display:inline-flex;align-items:center;gap:.4rem">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
              Changer la photo
            </label>
            <input type="file" id="avatar-input" accept="image/jpeg,image/png,image/webp"
              style="position:absolute;opacity:0;pointer-events:none;width:1px">
            <p class="mono" style="font-size:.72rem;margin-top:.3rem;color:var(--ink-soft)">JPG, PNG · Max 2 Mo</p>
          </div>
        </div>

        <form id="profile-form" novalidate>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
            <div class="form-group">
              <label for="settings-username">Pseudo</label>
              <input id="settings-username" name="username" type="text" class="form-input"
                value="${esc(profile?.username || '')}" maxlength="32"
                pattern="[a-zA-Z0-9_-]+" required>
            </div>
            <div class="form-group">
              <label for="settings-display-name">Nom affiché</label>
              <input id="settings-display-name" name="display_name" type="text" class="form-input"
                value="${esc(profile?.display_name || '')}" maxlength="60">
            </div>
          </div>
          <div class="form-group">
            <label for="settings-bio">Bio</label>
            <textarea id="settings-bio" name="bio" class="form-textarea"
              placeholder="Quelques mots sur vous et vos archives…"
              maxlength="500" rows="3">${esc(profile?.bio || '')}</textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-sm" id="save-profile-btn">
            Enregistrer le profil
          </button>
        </form>
      </section>

      <!-- ── Section Thème ── -->
      <section class="settings-section card" style="padding:1.75rem;margin-bottom:1.5rem">
        <h2 class="settings-section-title">Thème de couleur</h2>
        <p style="color:var(--ink-soft);font-size:.9rem;margin-bottom:1.25rem">
          Apparence de votre interface (sauvegardée dans votre profil).
        </p>
        <div class="theme-options">
          ${THEME_OPTIONS.map(opt => `
            <label class="theme-option ${(profile?.theme_preference || 'cream') === opt.value ? 'active' : ''}">
              <input type="radio" name="theme" value="${opt.value}"
                ${(profile?.theme_preference || 'cream') === opt.value ? 'checked' : ''}
                style="position:absolute;opacity:0">
              <span class="theme-swatch" style="background:${opt.color}">
                ${opt.emoji}
              </span>
              <span class="theme-option-label">${opt.label}</span>
            </label>
          `).join('')}
        </div>
      </section>

      <!-- ── Section Typographie ── -->
      <section class="settings-section card" style="padding:1.75rem;margin-bottom:1.5rem">
        <h2 class="settings-section-title">Typographie de mon profil public</h2>
        <p style="color:var(--ink-soft);font-size:.9rem;margin-bottom:1.25rem">
          La combinaison de polices appliquée sur votre page publique <code style="font-family:var(--fm);font-size:.85em">/u/${esc(profile?.username || '')}</code>.
        </p>
        <div class="font-options">
          ${FONT_OPTIONS.map(opt => `
            <label class="font-option ${(profile?.font_preference || 'classic') === opt.value ? 'active' : ''} font-theme-${opt.value}">
              <input type="radio" name="font_preference" value="${opt.value}"
                ${(profile?.font_preference || 'classic') === opt.value ? 'checked' : ''}
                style="position:absolute;opacity:0">
              <div class="font-option-preview">
                <span class="font-option-title">${opt.label}</span>
                <span class="font-option-sample">${opt.preview.sample}</span>
                <span class="font-option-desc mono">${opt.desc}</span>
              </div>
              <div class="font-option-check">✓</div>
            </label>
          `).join('')}
        </div>
        <button class="btn btn-primary btn-sm" id="save-font-btn" style="margin-top:1.25rem">
          Enregistrer la typographie
        </button>
      </section>

      <!-- ── Section Lien ── -->
      <section class="settings-section card" style="padding:1.75rem;margin-bottom:1.5rem">
        <h2 class="settings-section-title">Mon lien public</h2>
        <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap">
          <code style="font-family:var(--fm);font-size:.9rem;background:var(--bg-alt);padding:.5rem 1rem;border-radius:var(--radius-sm);flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            ${window.location.origin}/u/${esc(profile?.username || '')}
          </code>
          <button class="btn btn-ghost btn-sm" id="copy-profile-link">
            Copier
          </button>
        </div>
      </section>

      <!-- ── Déconnexion ── -->
      <div style="text-align:center;margin-top:2rem">
        <button class="btn btn-danger" id="signout-full-btn">Se déconnecter</button>
      </div>
    </div>

    <style>
    .settings-section-title {
      font-size:1.1rem; margin-bottom:1.25rem;
      padding-bottom:.6rem; border-bottom:1px solid var(--rule);
    }
    .theme-options { display:flex;gap:.75rem;flex-wrap:wrap; }
    .theme-option {
      display:flex;flex-direction:column;align-items:center;gap:.5rem;
      cursor:pointer; padding:.75rem; border-radius:var(--radius);
      border:2px solid var(--rule); transition:all .15s;
      position:relative; min-width:100px;
    }
    .theme-option.active, .theme-option:hover { border-color:var(--accent); background:var(--bg-alt); }
    .theme-swatch {
      width:48px;height:48px;border-radius:50%;
      display:flex;align-items:center;justify-content:center;
      font-size:1.4rem;border:2px solid var(--rule);
    }
    .theme-option-label { font-size:.82rem; text-align:center; color:var(--ink-mid); }
    .font-options { display:flex;flex-direction:column;gap:.6rem; }
    .font-option {
      display:flex;align-items:center;gap:1rem;
      padding:1rem 1.1rem; border-radius:var(--radius);
      border:2px solid var(--rule); cursor:pointer;
      transition:all .15s; position:relative;
    }
    .font-option.active, .font-option:hover { border-color:var(--accent); background:var(--bg-alt); }
    .font-option-preview { flex:1; }
    .font-option-title { display:block;font-size:1.05rem;font-weight:500;margin-bottom:.2rem; }
    .font-option-sample { display:block;font-style:italic;color:var(--ink-mid);font-size:.9rem;margin-bottom:.2rem; }
    .font-option-desc { font-size:.72rem;color:var(--ink-soft); }
    .font-option-check {
      width:24px;height:24px;border-radius:50%;
      background:var(--accent);color:#fff;
      display:flex;align-items:center;justify-content:center;
      font-size:.8rem;opacity:0;transition:opacity .15s;flex-shrink:0;
    }
    .font-option.active .font-option-check { opacity:1; }
    </style>
  `
}

window.SettingsHandlers = async function() {
  const profile = AppState.profile
  const errEl   = document.getElementById('settings-error')
  const succEl  = document.getElementById('settings-success')

  function showErr(msg)  { errEl.textContent  = msg; errEl.style.display  = 'block'; succEl.style.display = 'none' }
  function showSucc(msg) { succEl.textContent = msg; succEl.style.display = 'block'; errEl.style.display  = 'none' }

  // ── Avatar ──
  document.getElementById('avatar-input')?.addEventListener('change', async e => {
    const file = e.target.files[0]
    if (!file) return
    if (file.size > 2 * 1024 * 1024) { showErr('Avatar trop lourd (max 2 Mo).'); return }
    const { url, error } = await uploadAvatar(AppState.user.id, file)
    if (error) { showErr('Erreur upload avatar.'); return }
    await supabase.from('profiles').update({ avatar_url: url }).eq('id', AppState.user.id)
    AppState.profile.avatar_url = url
    // Rafraîchir l'aperçu
    const wrap = document.getElementById('avatar-preview-wrap')
    wrap.innerHTML = `<img src="${url}" alt="" class="avatar" style="width:72px;height:72px">`
    showSucc('Avatar mis à jour !')
  })

  // ── Profil ──
  document.getElementById('profile-form')?.addEventListener('submit', async e => {
    e.preventDefault()
    const username     = e.target.username.value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '')
    const display_name = e.target.display_name.value.trim()
    const bio          = e.target.bio.value.trim()
    const btn          = document.getElementById('save-profile-btn')

    if (!username) { showErr('Pseudo invalide.'); return }

    // Vérif unicité pseudo si changé
    if (username !== profile?.username) {
      const { data: ex } = await supabase.from('profiles').select('id').eq('username', username).single()
      if (ex) { showErr('Ce pseudo est déjà pris.'); return }
    }

    btn.disabled = true; btn.textContent = 'Enregistrement…'
    const { error } = await supabase.from('profiles')
      .update({ username, display_name, bio })
      .eq('id', AppState.user.id)

    if (error) { showErr('Erreur : ' + error.message); btn.disabled = false; btn.textContent = 'Enregistrer le profil'; return }
    await loadProfile(AppState.user.id)
    btn.disabled = false; btn.textContent = 'Enregistrer le profil'
    showSucc('Profil mis à jour !')
    // Mettre à jour l'URL si le pseudo a changé
    if (username !== profile?.username) navigate('/settings')
  })

  // ── Thème ──
  document.querySelectorAll('input[name="theme"]').forEach(radio => {
    radio.addEventListener('change', async () => {
      const theme = radio.value
      applyTheme(theme)
      document.querySelectorAll('.theme-option').forEach(el => el.classList.remove('active'))
      radio.closest('.theme-option').classList.add('active')
      await supabase.from('profiles').update({ theme_preference: theme }).eq('id', AppState.user.id)
      AppState.profile.theme_preference = theme
      showSucc('Thème mis à jour !')
    })
  })

  // ── Police ──
  document.querySelectorAll('input[name="font_preference"]').forEach(radio => {
    radio.addEventListener('change', () => {
      document.querySelectorAll('.font-option').forEach(el => el.classList.remove('active'))
      radio.closest('.font-option').classList.add('active')
    })
  })
  document.getElementById('save-font-btn')?.addEventListener('click', async () => {
    const selected = document.querySelector('input[name="font_preference"]:checked')?.value
    if (!selected) return
    const btn = document.getElementById('save-font-btn')
    btn.disabled = true; btn.textContent = 'Enregistrement…'
    await supabase.from('profiles').update({ font_preference: selected }).eq('id', AppState.user.id)
    AppState.profile.font_preference = selected
    btn.disabled = false; btn.textContent = 'Enregistrer la typographie'
    showSucc('Typographie mise à jour !')
  })

  // ── Copier lien ──
  document.getElementById('copy-profile-link')?.addEventListener('click', () => {
    const link = `${location.origin}/u/${AppState.profile?.username}`
    navigator.clipboard.writeText(link).then(() => showSucc('Lien copié !'))
  })

  // ── Déconnexion ──
  document.getElementById('signout-full-btn')?.addEventListener('click', async () => {
    await supabase.auth.signOut()
    AppState.user = null; AppState.profile = null
    navigate('/')
  })

  // data-link
  document.querySelectorAll('[data-link]').forEach(el => {
    el.addEventListener('click', e => { e.preventDefault(); navigate(el.getAttribute('href')) })
  })
}
