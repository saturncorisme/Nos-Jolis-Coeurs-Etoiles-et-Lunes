// src/pages/MyArchivesPage.js
export { renderMyArchivesPage } from './UserArchivesPage.js'
