// src/pages/UserArchivesPage.js
import { supabase } from '../lib/supabase.js'
import { renderArchiveCard } from '../components/ArchiveCard.js'
import { AppState, navigate } from '../main.js'

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
}

export async function renderUserArchivesPage(username) {
  const { data: profile } = await supabase
    .from('profiles').select('*').eq('username', username).single()

  if (!profile) return `<div class="container" style="padding:4rem;text-align:center">
    <h2>Profil introuvable</h2>
    <a href="/" data-link class="btn btn-ghost" style="margin-top:1rem">Retour</a>
  </div>`

  const { data: archives } = await supabase
    .from('archives')
    .select('*')
    .eq('user_id', profile.id)
    .order('created_at', { ascending: false })

  const isOwner = AppState.user?.id === profile.id
  const fontClass = `font-theme-${profile.font_preference || 'classic'}`
  const total = archives?.length || 0

  const html = `
    <div class="${fontClass}">
      <div class="container" style="padding-top:2.5rem;padding-bottom:4rem">
        <!-- Fil d'Ariane -->
        <nav style="margin-bottom:2rem;font-family:var(--fm);font-size:.8rem;color:var(--ink-soft)">
          <a href="/u/${esc(username)}" data-link style="color:var(--ink-soft)">@${esc(username)}</a>
          <span style="margin:0 .5rem">›</span>
          <span>Archives</span>
        </nav>

        <div style="display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:2rem">
          <div>
            <h1 style="font-style:italic">Toutes les archives</h1>
            <p class="mono" style="margin-top:.25rem">
              ${total} archive${total !== 1 ? 's' : ''} · @${esc(username)}
            </p>
          </div>
          ${isOwner
            ? `<a href="/archives/new" data-link class="btn btn-primary btn-sm">♡ Nouvelle archive</a>`
            : ''
          }
        </div>

        <!-- Filtres forme -->
        <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1.5rem">
          <button class="filter-btn active btn btn-ghost btn-sm" data-filter="all">Tout ♡ ☆ ☽</button>
          <button class="filter-btn btn btn-ghost btn-sm" data-filter="heart">
            <span class="badge-shape badge-heart">♡ Cœurs</span>
          </button>
          <button class="filter-btn btn btn-ghost btn-sm" data-filter="star">
            <span class="badge-shape badge-star">☆ Étoiles</span>
          </button>
          <button class="filter-btn btn btn-ghost btn-sm" data-filter="moon">
            <span class="badge-shape badge-moon">☽ Lunes</span>
          </button>
        </div>

        <div class="archives-grid" id="all-archives-grid"></div>

        ${total === 0
          ? `<div class="alert alert-info" style="text-align:center;padding:3rem;margin-top:1rem">
              <span style="font-size:2.5rem;display:block;margin-bottom:.5rem">☽</span>
              <p>Aucune archive pour l'instant.</p>
            </div>`
          : ''
        }
      </div>
    </div>
  `

  setTimeout(() => {
    const grid = document.getElementById('all-archives-grid')
    let allCards = []
    if (grid && archives) {
      archives.forEach(archive => {
        const card = renderArchiveCard(archive, {
          showOwnerActions: isOwner,
          onDelete: async (id) => {
            if (!confirm('Supprimer cette archive définitivement ?')) return
            await supabase.from('archives').delete().eq('id', id)
            navigate(`/u/${username}/archives`)
          }
        })
        card.dataset.shape = detectShape(archive.title)
        allCards.push(card)
        grid.appendChild(card)
      })
    }

    // Filtres
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'))
        btn.classList.add('active')
        const filter = btn.dataset.filter
        allCards.forEach(card => {
          card.style.display = filter === 'all' || card.dataset.shape === filter ? '' : 'none'
        })
      })
    })

    document.querySelectorAll('[data-link]').forEach(el => {
      el.addEventListener('click', e => { e.preventDefault(); navigate(el.getAttribute('href')) })
    })
  }, 50)

  return html
}

function detectShape(title = '') {
  const t = title.toLowerCase()
  if (t.includes('cœur') || t.includes('coeur') || t.includes('heart')) return 'heart'
  if (t.includes('étoile') || t.includes('etoile') || t.includes('star')) return 'star'
  if (t.includes('lune') || t.includes('moon')) return 'moon'
  return 'heart'
}

// ═══════════════════════════════════════════════════════════
// MY ARCHIVES PAGE (vue connectée)
// ═══════════════════════════════════════════════════════════
export async function renderMyArchivesPage() {
  const user = AppState.user
  if (!user) { navigate('/login'); return '' }

  const { data: archives } = await supabase
    .from('archives')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })

  const total = archives?.length || 0

  const html = `
    <div class="container" style="padding-top:2.5rem;padding-bottom:4rem">
      <div style="display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:2rem">
        <div>
          <h1 style="font-style:italic">Mes archives</h1>
          <p class="mono" style="margin-top:.25rem">${total} archive${total !== 1 ? 's' : ''}</p>
        </div>
        <a href="/archives/new" data-link class="btn btn-primary">
          ♡ Nouvelle archive
        </a>
      </div>

      <div class="archives-grid" id="my-archives-grid"></div>

      ${total === 0
        ? `<div class="alert alert-info" style="text-align:center;padding:3rem">
            <span style="font-size:2.5rem;display:block;margin-bottom:.5rem">☽</span>
            <p>Vous n'avez pas encore d'archives.</p>
            <a href="/archives/new" data-link class="btn btn-primary btn-sm" style="margin-top:1rem">
              Commencer mon archive
            </a>
          </div>`
        : ''
      }
    </div>
  `

  setTimeout(() => {
    const grid = document.getElementById('my-archives-grid')
    if (grid && archives) {
      archives.forEach(archive => {
        grid.appendChild(renderArchiveCard(archive, {
          showOwnerActions: true,
          onDelete: async (id) => {
            if (!confirm('Supprimer cette archive définitivement ?')) return
            await supabase.from('archives').delete().eq('id', id)
            navigate('/my-archives')
          }
        }))
      })
    }
    document.querySelectorAll('[data-link]').forEach(el => {
      el.addEventListener('click', e => { e.preventDefault(); navigate(el.getAttribute('href')) })
    })
  }, 50)

  return html
}
