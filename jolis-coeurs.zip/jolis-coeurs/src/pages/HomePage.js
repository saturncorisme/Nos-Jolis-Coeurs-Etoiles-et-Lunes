// src/pages/HomePage.js
import { AppState } from '../main.js'

export async function renderHomePage() {
  const isConnected = !!AppState.user
  const profile = AppState.profile

  return `
    <style>
    .hero {
      min-height: 80vh;
      display: flex; flex-direction: column;
      align-items: center; justify-content: center;
      text-align: center; padding: 4rem 1.5rem;
      position: relative; overflow: hidden;
    }
    .hero::before {
      content: '';
      position: absolute; inset: 0;
      background: radial-gradient(ellipse at 50% 0%, var(--bg-alt) 0%, transparent 70%);
      pointer-events: none;
    }
    .hero-symbols {
      font-size: clamp(2.5rem, 8vw, 5rem);
      letter-spacing: .5rem;
      margin-bottom: 1.5rem;
      animation: float 6s ease-in-out infinite;
    }
    @keyframes float {
      0%, 100% { transform: translateY(0); }
      50%       { transform: translateY(-10px); }
    }
    .hero h1 {
      font-size: clamp(2rem, 5vw, 3.8rem);
      font-style: italic; font-weight: 700;
      line-height: 1.1; margin-bottom: 1rem;
      max-width: 780px;
    }
    .hero h1 em { color: var(--accent); font-style: normal; }
    .hero p {
      font-size: clamp(.95rem, 2vw, 1.2rem);
      color: var(--ink-mid); max-width: 560px;
      line-height: 1.8; margin-bottom: 2.5rem;
    }
    .hero-cta { display: flex; gap: 1rem; flex-wrap: wrap; justify-content: center; }

    .features {
      padding: 4rem 0;
      display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 1.5rem;
    }
    .feature-card {
      background: var(--bg-card);
      border: 1px solid var(--rule);
      border-radius: var(--radius);
      padding: 1.75rem 1.5rem;
      text-align: center;
    }
    .feature-icon {
      font-size: 2.5rem; margin-bottom: 1rem;
      display: block;
      animation: float 5s ease-in-out infinite;
    }
    .feature-card:nth-child(2) .feature-icon { animation-delay: -2s; }
    .feature-card:nth-child(3) .feature-icon { animation-delay: -4s; }
    .feature-card h3 { font-size: 1.1rem; margin-bottom: .5rem; }
    .feature-card p  { color: var(--ink-mid); font-size: .9rem; line-height: 1.6; margin: 0; }

    .how-section { padding: 3rem 0 5rem; text-align: center; }
    .how-section h2 { font-style: italic; margin-bottom: 2.5rem; }
    .steps {
      display: flex; gap: 1.5rem; flex-wrap: wrap; justify-content: center;
    }
    .step {
      flex: 1; min-width: 180px; max-width: 220px;
    }
    .step-num {
      width: 42px; height: 42px; border-radius: 50%;
      background: var(--accent); color: #fff;
      font-family: var(--fd); font-size: 1.1rem;
      display: flex; align-items: center; justify-content: center;
      margin: 0 auto .75rem;
    }
    .step h4 { margin-bottom: .4rem; font-size: 1rem; }
    .step p  { font-size: .88rem; color: var(--ink-soft); margin: 0; }
    </style>

    <!-- HERO -->
    <section class="hero">
      <div class="hero-symbols" aria-hidden="true">♡ ☆ ☽</div>
      <h1>Les <em>Jolis</em> Cœurs,<br>Étoiles & Lunes<br>du Monde</h1>
      <p>
        Une bibliothèque poétique de formes trouvées dans les rues —
        tags, stickers, ombres, architectures. Chaque forme a une histoire.
      </p>
      ${isConnected
        ? `<div class="hero-cta">
            <a href="/archives/new" data-link class="btn btn-primary">
              ♡ Ajouter une archive
            </a>
            <a href="/u/${profile?.username || ''}" data-link class="btn btn-ghost">
              Voir mon profil
            </a>
          </div>`
        : `<div class="hero-cta">
            <a href="/signup" data-link class="btn btn-primary">
              Commencer mon archive
            </a>
            <a href="/login" data-link class="btn btn-ghost">
              Se connecter
            </a>
          </div>`
      }
    </section>

    <!-- FEATURES -->
    <section class="container" aria-labelledby="features-title">
      <h2 id="features-title" class="divider" style="font-style:italic;justify-content:center;font-size:1.4rem">
        Ce que vous archivez
      </h2>
      <div class="features">
        <div class="feature-card">
          <span class="feature-icon" aria-hidden="true">♡</span>
          <h3>Les Cœurs</h3>
          <p>Graffitis, fissures, taches, vitres — les cœurs se cachent partout pour qui sait les voir.</p>
        </div>
        <div class="feature-card">
          <span class="feature-icon" aria-hidden="true">☆</span>
          <h3>Les Étoiles</h3>
          <p>Éclats de verre, motifs de carrelage, ombres de rambardes au soleil couchant.</p>
        </div>
        <div class="feature-card">
          <span class="feature-icon" aria-hidden="true">☽</span>
          <h3>Les Lunes</h3>
          <p>Croissants de rouille, reflets dans les flaques, découpes d'enseignes oubliées.</p>
        </div>
      </div>
    </section>

    <!-- HOW IT WORKS -->
    <section class="how-section container" aria-labelledby="how-title">
      <h2 id="how-title">Comment ça marche</h2>
      <div class="steps">
        <div class="step">
          <div class="step-num">1</div>
          <h4>Photographiez</h4>
          <p>Capturez la forme trouvée dans la rue avec votre téléphone.</p>
        </div>
        <div class="step">
          <div class="step-num">2</div>
          <h4>Archivez</h4>
          <p>Ajoutez un titre, racontez l'histoire, localisez l'endroit.</p>
        </div>
        <div class="step">
          <div class="step-num">3</div>
          <h4>Partagez</h4>
          <p>Partagez le lien de votre profil — votre bibliothèque, votre regard.</p>
        </div>
      </div>
    </section>
  `
}
