// src/pages/ArchiveDetailPage.js
import { supabase } from '../lib/supabase.js'
import { renderMapView } from '../components/MapView.js'
import { AppState, navigate } from '../main.js'

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
}
function formatDate(ts) {
  if (!ts) return ''
  return new Date(ts).toLocaleDateString('fr-FR', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
  })
}

const SHAPE_ICONS = {
  cœur: '♡', coeur: '♡', heart: '♡',
  étoile: '☆', etoile: '☆', star: '☆',
  lune: '☽', moon: '☽',
}

function detectIcon(title = '') {
  const t = title.toLowerCase()
  for (const [k, v] of Object.entries(SHAPE_ICONS)) {
    if (t.includes(k)) return v
  }
  return '♡'
}

export async function renderArchiveDetailPage(id) {
  const { data: archive, error } = await supabase
    .from('archives')
    .select('*, profiles(username, display_name, avatar_url, font_preference)')
    .eq('id', id)
    .single()

  if (error || !archive) {
    return `<div class="container" style="text-align:center;padding:5rem 1rem">
      <div style="font-size:3rem">☽</div>
      <h1 style="font-style:italic">Archive introuvable</h1>
      <p style="color:var(--ink-soft)">Cette archive n'existe pas ou a été supprimée.</p>
      <a href="/" data-link class="btn btn-ghost" style="margin-top:1.5rem">Retour à l'accueil</a>
    </div>`
  }

  const profile   = archive.profiles
  const isOwner   = AppState.user?.id === archive.user_id
  const icon      = detectIcon(archive.title)
  const fontClass = `font-theme-${profile?.font_preference || 'classic'}`
  const hasCoords = archive.latitude && archive.longitude

  const html = `
    <div class="${fontClass}">
      <style>
      .archive-detail {
        display: grid;
        grid-template-columns: 1fr 1fr;
        min-height: 85vh;
        gap: 0;
      }
      @media (max-width: 768px) {
        .archive-detail { grid-template-columns: 1fr; }
        .archive-detail-img-col { min-height: 300px; max-height: 60vw; }
      }
      .archive-detail-img-col {
        position: sticky; top: 60px;
        height: calc(100vh - 60px);
        background: var(--bg-alt);
        overflow: hidden;
        display: flex; align-items: center; justify-content: center;
      }
      .archive-detail-img {
        width: 100%; height: 100%;
        object-fit: cover;
      }
      .archive-detail-ph {
        font-size: 8rem; color: var(--accent); opacity: .3;
      }
      .archive-detail-info {
        padding: 3rem 2.5rem 4rem;
        overflow-y: auto;
      }
      @media (max-width: 768px) {
        .archive-detail-info { padding: 2rem 1.25rem 3rem; }
      }
      .archive-detail-breadcrumb {
        font-family: var(--fm); font-size: .78rem;
        color: var(--ink-soft); margin-bottom: 1.75rem;
      }
      .archive-detail-breadcrumb a { color: var(--ink-soft); }
      .archive-detail-breadcrumb a:hover { color: var(--accent); }
      .archive-detail-icon {
        font-size: 2.5rem; display: block; margin-bottom: .75rem;
      }
      .archive-detail-title {
        font-size: clamp(1.6rem, 4vw, 2.5rem);
        font-style: italic; margin-bottom: .4rem;
      }
      .archive-detail-date {
        font-family: var(--fm); font-size: .8rem;
        color: var(--ink-soft); margin-bottom: 2rem;
      }
      .archive-detail-story {
        font-size: 1.05rem; line-height: 1.9;
        color: var(--ink-mid);
        margin-bottom: 2rem;
        white-space: pre-wrap;
      }
      .archive-detail-section-title {
        font-family: var(--fm); font-size: .72rem;
        letter-spacing: .1em; text-transform: uppercase;
        color: var(--ink-soft); margin-bottom: .6rem;
        border-bottom: 1px solid var(--rule); padding-bottom: .4rem;
      }
      .archive-detail-coords {
        font-family: var(--fm); font-size: .85rem;
        color: var(--ink-mid); margin-bottom: 1.25rem;
      }
      .archive-detail-author {
        display: flex; align-items: center; gap: .75rem;
        padding: 1rem; background: var(--bg-alt);
        border-radius: var(--radius-sm); margin-bottom: 1.5rem;
        text-decoration: none; color: var(--ink);
        transition: background .15s;
      }
      .archive-detail-author:hover { background: var(--bg); color: var(--ink); text-decoration: none; }
      .archive-detail-actions { display: flex; gap: .75rem; flex-wrap: wrap; margin-top: 1.5rem; }
      </style>

      <div class="archive-detail">
        <!-- Image -->
        <div class="archive-detail-img-col">
          ${archive.photo_url
            ? `<img src="${esc(archive.photo_url)}" alt="${esc(archive.title)}" class="archive-detail-img">`
            : `<span class="archive-detail-ph" aria-hidden="true">${icon}</span>`
          }
        </div>

        <!-- Infos -->
        <div class="archive-detail-info">
          <nav class="archive-detail-breadcrumb">
            <a href="/" data-link>Accueil</a> ›
            <a href="/u/${esc(profile?.username)}" data-link>@${esc(profile?.username)}</a> ›
            <span>${esc(archive.title)}</span>
          </nav>

          <span class="archive-detail-icon" aria-hidden="true">${icon}</span>
          <h1 class="archive-detail-title">${esc(archive.title)}</h1>
          <p class="archive-detail-date">${formatDate(archive.created_at)}</p>

          ${archive.story ? `
            <div class="archive-detail-section-title">Histoire</div>
            <p class="archive-detail-story story">${esc(archive.story)}</p>
          ` : ''}

          ${hasCoords ? `
            <div class="archive-detail-section-title">Localisation</div>
            <p class="archive-detail-coords">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              ${archive.latitude.toFixed(5)}, ${archive.longitude.toFixed(5)}
            </p>
            <div id="map-container" style="margin-bottom:1.75rem">
              ${renderMapView(archive.latitude, archive.longitude, archive.title)}
            </div>
          ` : ''}

          <!-- Auteur -->
          <div class="archive-detail-section-title">Archivé par</div>
          <a href="/u/${esc(profile?.username)}" data-link class="archive-detail-author">
            ${profile?.avatar_url
              ? `<img src="${esc(profile.avatar_url)}" alt="" class="avatar" style="width:40px;height:40px">`
              : `<div class="avatar-placeholder" style="width:40px;height:40px;font-size:1.1rem">
                  ${(profile?.display_name || profile?.username || '?')[0].toUpperCase()}
                </div>`
            }
            <div>
              <div style="font-weight:500">${esc(profile?.display_name || profile?.username)}</div>
              <div class="mono">@${esc(profile?.username)}</div>
            </div>
          </a>

          <!-- Partage -->
          <div class="archive-detail-section-title">Partager</div>
          <div class="archive-detail-actions">
            <button class="btn btn-ghost btn-sm" id="copy-archive-link">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              Copier le lien
            </button>
            ${isOwner ? `
              <button class="btn btn-danger btn-sm" id="delete-archive-btn" data-id="${esc(archive.id)}">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
                Supprimer
              </button>
            ` : ''}
          </div>
        </div>
      </div>
    </div>
  `

  setTimeout(() => {
    document.getElementById('copy-archive-link')?.addEventListener('click', () => {
      navigator.clipboard.writeText(window.location.href)
        .then(() => alert('Lien copié !'))
        .catch(() => alert(`Lien : ${window.location.href}`))
    })

    document.getElementById('delete-archive-btn')?.addEventListener('click', async () => {
      if (!confirm('Supprimer cette archive définitivement ?')) return
      await supabase.from('archives').delete().eq('id', id)
      navigate(`/u/${profile?.username || ''}`)
    })

    document.querySelectorAll('[data-link]').forEach(el => {
      el.addEventListener('click', e => { e.preventDefault(); navigate(el.getAttribute('href')) })
    })
  }, 50)

  return html
}
