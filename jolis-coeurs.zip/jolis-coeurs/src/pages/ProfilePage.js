// src/pages/ProfilePage.js
import { supabase } from '../lib/supabase.js'
import { renderArchiveCard } from '../components/ArchiveCard.js'
import { AppState, navigate } from '../main.js'

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
}

export async function renderProfilePage(username) {
  // Charger le profil
  const { data: profile, error } = await supabase
    .from('profiles').select('*').eq('username', username).single()

  if (error || !profile) {
    return `
      <div class="container" style="text-align:center;padding:5rem 1rem">
        <div style="font-size:3rem">☽</div>
        <h1 style="font-style:italic;margin:.5rem 0">Profil introuvable</h1>
        <p style="color:var(--ink-soft)">L'utilisateur « ${esc(username)} » n'existe pas.</p>
        <a href="/" data-link class="btn btn-ghost" style="margin-top:1.5rem">Retour à l'accueil</a>
      </div>`
  }

  // Charger les archives (6 dernières pour la page profil)
  const { data: archives } = await supabase
    .from('archives')
    .select('*')
    .eq('user_id', profile.id)
    .order('created_at', { ascending: false })
    .limit(6)

  const isOwner = AppState.user?.id === profile.id
  const fontClass = `font-theme-${profile.font_preference || 'classic'}`

  const html = `
    <div class="${fontClass}">
      <style>
      .profile-hero {
        background: var(--bg-alt);
        border-bottom: 1px solid var(--rule);
        padding: 3.5rem 0 2.5rem;
        text-align: center;
      }
      .profile-hero-inner { max-width: 600px; margin: 0 auto; padding: 0 1.5rem; }
      .profile-avatar-wrap { margin-bottom: 1.2rem; }
      .profile-bio {
        font-style: italic; color: var(--ink-mid);
        max-width: 480px; margin: .75rem auto 0;
        line-height: 1.8; font-size: 1rem;
      }
      .profile-meta {
        display: flex; justify-content: center; gap: 2rem;
        margin-top: 1.25rem; flex-wrap: wrap;
      }
      .profile-meta-item { text-align: center; }
      .profile-meta-num {
        font-family: var(--fd); font-size: 1.6rem; font-weight: 700;
        display: block; color: var(--ink);
      }
      .profile-meta-label {
        font-family: var(--fm); font-size: .7rem;
        text-transform: uppercase; letter-spacing: .08em;
        color: var(--ink-soft);
      }
      .profile-share {
        margin-top: 1.25rem; display: flex; gap: .75rem;
        justify-content: center; flex-wrap: wrap;
      }
      </style>

      <!-- En-tête profil -->
      <section class="profile-hero">
        <div class="profile-hero-inner">
          <div class="profile-avatar-wrap">
            ${profile.avatar_url
              ? `<img src="${esc(profile.avatar_url)}" alt="${esc(profile.display_name)}"
                  class="avatar" style="width:90px;height:90px;margin:0 auto">`
              : `<div class="avatar-placeholder" style="width:90px;height:90px;font-size:2rem;margin:0 auto">
                  ${(profile.display_name || profile.username || '?')[0].toUpperCase()}
                </div>`
            }
          </div>
          <h1 style="font-size:1.8rem;font-style:italic">${esc(profile.display_name || profile.username)}</h1>
          <p class="mono" style="margin-top:.3rem">@${esc(profile.username)}</p>
          ${profile.bio
            ? `<p class="profile-bio">${esc(profile.bio)}</p>`
            : ''
          }
          <div class="profile-meta">
            <div class="profile-meta-item">
              <span class="profile-meta-num">${archives?.length || 0}${(archives?.length ?? 0) >= 6 ? '+' : ''}</span>
              <span class="profile-meta-label">Archives</span>
            </div>
          </div>
          <div class="profile-share">
            ${isOwner
              ? `<a href="/settings" data-link class="btn btn-ghost btn-sm">Modifier mon profil</a>
                 <a href="/archives/new" data-link class="btn btn-primary btn-sm">♡ Ajouter une archive</a>`
              : ''
            }
            <button class="btn btn-ghost btn-sm" id="copy-link-btn">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              Copier le lien
            </button>
          </div>
        </div>
      </section>

      <!-- Aperçu archives -->
      <section class="container" style="padding-top:2.5rem;padding-bottom:3rem">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:.75rem">
          <h2 style="font-style:italic;font-size:1.3rem">Archives récentes</h2>
          <a href="/u/${esc(profile.username)}/archives" data-link class="btn btn-ghost btn-sm">
            Voir tout →
          </a>
        </div>

        ${!archives || archives.length === 0
          ? `<div class="alert alert-info" style="text-align:center;padding:3rem">
              <span style="font-size:2rem;display:block;margin-bottom:.75rem">☽</span>
              <p>Aucune archive pour l'instant.</p>
              ${isOwner ? `<a href="/archives/new" data-link class="btn btn-primary btn-sm" style="margin-top:1rem">
                Ajouter ma première archive
              </a>` : ''}
            </div>`
          : `<div class="archives-grid" id="profile-archives-grid"></div>
             ${archives.length >= 6
               ? `<div style="text-align:center;margin-top:2rem">
                    <a href="/u/${esc(profile.username)}/archives" data-link class="btn btn-ghost">
                      Voir toutes les archives →
                    </a>
                  </div>`
               : ''
             }`
        }
      </section>
    </div>
  `

  // Injecter les cartes après rendu
  setTimeout(() => {
    const grid = document.getElementById('profile-archives-grid')
    if (grid && archives) {
      archives.forEach(archive => {
        grid.appendChild(renderArchiveCard(archive, {
          showOwnerActions: isOwner,
          onDelete: async (id) => {
            if (!confirm('Supprimer cette archive ?')) return
            await supabase.from('archives').delete().eq('id', id)
            navigate(`/u/${profile.username}`)
          }
        }))
      })
    }

    // Copier le lien
    document.getElementById('copy-link-btn')?.addEventListener('click', () => {
      navigator.clipboard.writeText(window.location.href)
        .then(() => alert('Lien copié !'))
        .catch(() => alert(`Lien : ${window.location.href}`))
    })

    // Data-link
    document.querySelectorAll('[data-link]').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault()
        navigate(el.getAttribute('href'))
      })
    })
  }, 50)

  return html
}
