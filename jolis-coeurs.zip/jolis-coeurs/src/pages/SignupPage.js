// src/pages/SignupPage.js
export { renderSignupPage } from './LoginPage.js'
