// src/main.js — SPA Router vanilla JS
import { supabase, getSession } from './lib/supabase.js'
import { renderHeader } from './components/Header.js'
import { renderFooter } from './components/Footer.js'
import { renderHomePage } from './pages/HomePage.js'
import { renderLoginPage } from './pages/LoginPage.js'
import { renderSignupPage } from './pages/SignupPage.js'
import { renderProfilePage } from './pages/ProfilePage.js'
import { renderUserArchivesPage } from './pages/UserArchivesPage.js'
import { renderArchiveDetailPage } from './pages/ArchiveDetailPage.js'
import { renderNewArchivePage } from './pages/NewArchivePage.js'
import { renderSettingsPage } from './pages/SettingsPage.js'
import { renderMyArchivesPage } from './pages/MyArchivesPage.js'

/* ── État global ── */
export const AppState = {
  user: null,
  profile: null,
  theme: localStorage.getItem('theme') || 'cream',
}

/* ── Appliquer thème ── */
export function applyTheme(theme) {
  AppState.theme = theme
  document.documentElement.setAttribute('data-theme', theme)
  localStorage.setItem('theme', theme)
}

/* ── Routeur SPA simple basé sur l'URL hash ── */
export async function navigate(path) {
  history.pushState({}, '', path)
  await renderRoute(path)
}

async function renderRoute(path) {
  const app = document.getElementById('app')

  // Scroll en haut
  window.scrollTo(0, 0)

  // Toujours re-rendre le header avec l'état actuel
  const headerEl = document.getElementById('site-header')
  if (headerEl) headerEl.outerHTML = await renderHeader()
  else {
    app.innerHTML = (await renderHeader()) + '<main id="main-content"></main>' + renderFooter()
  }

  const main = document.getElementById('main-content')
  if (!main) return

  // Parser le path
  const segments = path.replace(/^\//, '').split('/')

  // Routes
  if (path === '/' || path === '') {
    main.innerHTML = await renderHomePage()
  }
  else if (path === '/login') {
    main.innerHTML = await renderLoginPage()
    attachLoginEvents()
  }
  else if (path === '/signup') {
    main.innerHTML = await renderSignupPage()
    attachSignupEvents()
  }
  else if (path === '/settings') {
    if (!AppState.user) { navigate('/login'); return }
    main.innerHTML = await renderSettingsPage()
    attachSettingsEvents()
  }
  else if (path === '/archives/new') {
    if (!AppState.user) { navigate('/login'); return }
    main.innerHTML = await renderNewArchivePage()
    attachNewArchiveEvents()
  }
  else if (path === '/my-archives') {
    if (!AppState.user) { navigate('/login'); return }
    main.innerHTML = await renderMyArchivesPage()
  }
  else if (segments[0] === 'u' && segments[1] && !segments[2]) {
    main.innerHTML = await renderProfilePage(segments[1])
  }
  else if (segments[0] === 'u' && segments[1] && segments[2] === 'archives') {
    main.innerHTML = await renderUserArchivesPage(segments[1])
  }
  else if (segments[0] === 'a' && segments[1]) {
    main.innerHTML = await renderArchiveDetailPage(segments[1])
  }
  else {
    main.innerHTML = `
      <div class="container" style="text-align:center;padding:6rem 1rem">
        <h1 style="font-style:italic">Page introuvable</h1>
        <p style="color:var(--ink-soft);margin:1rem 0 2rem">
          Cette page n'existe pas ou a été déplacée.
        </p>
        <a href="/" class="btn btn-primary" data-link>Retour à l'accueil</a>
      </div>`
  }

  // Délégation liens [data-link]
  attachLinkDelegation()
}

/* ── Délégation de navigation SPA ── */
function attachLinkDelegation() {
  document.querySelectorAll('[data-link]').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault()
      const href = el.getAttribute('href')
      if (href) navigate(href)
    })
  })
}

/* ── Events formulaire connexion ── */
function attachLoginEvents() {
  const form = document.getElementById('login-form')
  if (!form) return
  form.addEventListener('submit', async e => {
    e.preventDefault()
    const email    = form.email.value.trim()
    const password = form.password.value
    const btn      = form.querySelector('[type=submit]')
    const errEl    = document.getElementById('login-error')
    btn.disabled   = true
    btn.textContent = 'Connexion…'
    errEl.textContent = ''

    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) {
      errEl.textContent = 'Email ou mot de passe incorrect.'
      btn.disabled = false
      btn.textContent = 'Se connecter'
      return
    }
    AppState.user = data.user
    await loadProfile(data.user.id)
    navigate('/')
  })

  const forgotLink = document.getElementById('forgot-link')
  if (forgotLink) {
    forgotLink.addEventListener('click', async e => {
      e.preventDefault()
      const email = document.getElementById('login-email').value.trim()
      if (!email) {
        document.getElementById('login-error').textContent = 'Entrez votre email ci-dessus.'
        return
      }
      await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${location.origin}/reset-password`
      })
      document.getElementById('login-error').textContent = ''
      document.getElementById('login-success').textContent =
        'Email de réinitialisation envoyé ! Vérifiez votre boîte.'
    })
  }
}

/* ── Events formulaire inscription ── */
function attachSignupEvents() {
  const form = document.getElementById('signup-form')
  if (!form) return
  form.addEventListener('submit', async e => {
    e.preventDefault()
    const email    = form.email.value.trim()
    const password = form.password.value
    const username = form.username.value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '')
    const name     = form.display_name.value.trim()
    const errEl    = document.getElementById('signup-error')
    const btn      = form.querySelector('[type=submit]')
    btn.disabled   = true
    btn.textContent = 'Création…'
    errEl.textContent = ''

    if (!username) {
      errEl.textContent = 'Pseudo invalide (lettres, chiffres, _ - uniquement).'
      btn.disabled = false; btn.textContent = 'Créer mon compte'; return
    }
    if (password.length < 6) {
      errEl.textContent = 'Mot de passe trop court (6 caractères minimum).'
      btn.disabled = false; btn.textContent = 'Créer mon compte'; return
    }

    // Vérif pseudo disponible
    const { data: existing } = await supabase
      .from('profiles').select('id').eq('username', username).single()
    if (existing) {
      errEl.textContent = 'Ce pseudo est déjà pris.'
      btn.disabled = false; btn.textContent = 'Créer mon compte'; return
    }

    const { data, error } = await supabase.auth.signUp({ email, password })
    if (error) {
      errEl.textContent = error.message
      btn.disabled = false; btn.textContent = 'Créer mon compte'; return
    }

    // Créer le profil
    await supabase.from('profiles').insert({
      id: data.user.id,
      username,
      display_name: name || username,
      bio: '',
      theme_preference: 'cream',
      font_preference: 'classic',
    })

    AppState.user = data.user
    await loadProfile(data.user.id)
    navigate('/settings')
  })
}

/* ── Charger le profil de l'utilisateur connecté ── */
export async function loadProfile(userId) {
  const { data } = await supabase
    .from('profiles').select('*').eq('id', userId).single()
  AppState.profile = data
  if (data?.theme_preference) applyTheme(data.theme_preference)
  return data
}

/* ── Events settings ── */
function attachSettingsEvents() {
  // Délégué à SettingsPage.js via window.SettingsHandlers
  if (window.SettingsHandlers) window.SettingsHandlers()
}

/* ── Events nouvelle archive ── */
function attachNewArchiveEvents() {
  if (window.NewArchiveHandlers) window.NewArchiveHandlers()
}

/* ── Init de l'app ── */
async function init() {
  applyTheme(AppState.theme)

  // Écouter les changements d'auth
  supabase.auth.onAuthStateChange(async (event, session) => {
    if (session?.user) {
      AppState.user = session.user
      await loadProfile(session.user.id)
    } else {
      AppState.user = null
      AppState.profile = null
    }
  })

  // Récupérer session existante
  const session = await getSession()
  if (session?.user) {
    AppState.user = session.user
    await loadProfile(session.user.id)
  }

  // Rendre la structure initiale
  const app = document.getElementById('app')
  app.innerHTML = (await renderHeader()) + '<main id="main-content"></main>' + renderFooter()

  // Naviguer vers la route actuelle
  await renderRoute(location.pathname)

  // Navigation navigateur (boutons précédent/suivant)
  window.addEventListener('popstate', () => renderRoute(location.pathname))

  // Délégation globale
  attachLinkDelegation()
}

init()
