// src/components/Footer.js
export function renderFooter() {
  return `
    <footer class="site-footer">
      <div class="container footer-inner">
        <div class="footer-logo">
          <img src="/logo.svg" alt="" width="28" height="28" aria-hidden="true">
          <span style="font-family:var(--fd);font-style:italic;font-size:.95rem">
            Jolis ♡ ☆ ☽ du monde
          </span>
        </div>
        <p class="footer-tagline">
          Une bibliothèque poétique des formes cachées dans les rues du monde.
        </p>
        <p class="mono" style="margin-top:.5rem">
          Archives personnelles · Pas de réseau social · Fait avec ♡
        </p>
      </div>
    </footer>
    <style id="footer-styles">
    .site-footer {
      margin-top: 5rem;
      border-top: 1px solid var(--rule);
      padding: 2.5rem 0;
      text-align: center;
    }
    .footer-inner { display:flex;flex-direction:column;align-items:center;gap:.6rem; }
    .footer-logo  { display:flex;align-items:center;gap:.5rem;color:var(--ink-mid); }
    .footer-tagline {
      font-family: var(--fb); font-style: italic;
      color: var(--ink-soft); font-size: .9rem;
    }
    </style>
  `
}
