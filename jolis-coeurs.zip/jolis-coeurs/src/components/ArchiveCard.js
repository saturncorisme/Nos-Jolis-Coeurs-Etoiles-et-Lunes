// src/components/ArchiveCard.js
import { navigate } from '../main.js'

const SHAPE_ICONS = { heart: '♡', star: '☆', moon: '☽', coeur: '♡', etoile: '☆', lune: '☽' }
const SHAPE_BADGE = { heart: 'badge-heart', star: 'badge-star', moon: 'badge-moon',
                      coeur: 'badge-heart', etoile: 'badge-star', lune: 'badge-moon' }

function detectShape(title = '') {
  const t = title.toLowerCase()
  if (t.includes('cœur') || t.includes('coeur') || t.includes('heart')) return 'heart'
  if (t.includes('étoile') || t.includes('etoile') || t.includes('star')) return 'star'
  if (t.includes('lune') || t.includes('moon')) return 'moon'
  return 'heart'
}

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
}

function formatDate(ts) {
  if (!ts) return ''
  return new Date(ts).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })
}

export function renderArchiveCard(archive, { showOwnerActions = false, onDelete } = {}) {
  const shape  = detectShape(archive.title)
  const icon   = SHAPE_ICONS[shape]
  const badge  = SHAPE_BADGE[shape]
  const coords = archive.latitude && archive.longitude
    ? `${archive.latitude.toFixed(4)}, ${archive.longitude.toFixed(4)}`
    : null

  const card = document.createElement('article')
  card.className = 'card archive-card'
  card.setAttribute('role', 'article')
  card.style.cursor = 'pointer'

  card.innerHTML = `
    <div class="archive-card-img-wrap">
      ${archive.photo_url
        ? `<img src="${esc(archive.photo_url)}" alt="${esc(archive.title)}" class="archive-card-img" loading="lazy">`
        : `<div class="archive-card-placeholder">${icon}</div>`
      }
      <span class="badge-shape ${badge} archive-card-badge">${icon} ${esc(archive.title)}</span>
    </div>
    <div class="archive-card-body">
      <h3 class="archive-card-title">${esc(archive.title)}</h3>
      ${archive.story
        ? `<p class="archive-card-story">${esc(archive.story.slice(0, 120))}${archive.story.length > 120 ? '…' : ''}</p>`
        : ''
      }
      <div class="archive-card-meta">
        ${coords ? `<span class="mono">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          ${esc(coords)}
        </span>` : ''}
        <span class="mono">${formatDate(archive.created_at)}</span>
      </div>
      ${showOwnerActions ? `
        <div class="archive-card-actions">
          <button class="btn btn-ghost btn-sm edit-btn" data-id="${esc(archive.id)}">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            Modifier
          </button>
          <button class="btn btn-danger btn-sm delete-btn" data-id="${esc(archive.id)}">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
            Supprimer
          </button>
        </div>
      ` : ''}
    </div>
  `

  // Navigation au clic sur la carte (pas sur les boutons)
  card.addEventListener('click', e => {
    if (e.target.closest('.archive-card-actions')) return
    navigate(`/a/${archive.id}`)
  })

  // Actions propriétaire
  if (showOwnerActions) {
    card.querySelector('.edit-btn')?.addEventListener('click', e => {
      e.stopPropagation()
      navigate(`/archives/${archive.id}/edit`)
    })
    card.querySelector('.delete-btn')?.addEventListener('click', e => {
      e.stopPropagation()
      if (onDelete) onDelete(archive.id)
    })
  }

  return card
}

// CSS carte — injecté une seule fois
if (!document.getElementById('archive-card-styles')) {
  document.head.insertAdjacentHTML('beforeend', `
  <style id="archive-card-styles">
  .archive-card { transition: box-shadow .2s, transform .2s; }
  .archive-card:hover { transform: translateY(-3px); box-shadow: 0 8px 32px var(--shadow-md); }
  .archive-card-img-wrap { position: relative; aspect-ratio: 4/3; overflow: hidden; }
  .archive-card-img {
    width: 100%; height: 100%; object-fit: cover;
    transition: transform .4s ease;
  }
  .archive-card:hover .archive-card-img { transform: scale(1.04); }
  .archive-card-placeholder {
    width: 100%; height: 100%;
    background: var(--bg-alt);
    display: flex; align-items: center; justify-content: center;
    font-size: 3.5rem; color: var(--accent);
  }
  .archive-card-badge {
    position: absolute; bottom: .6rem; left: .6rem;
    backdrop-filter: blur(6px);
    background: rgba(255,255,255,.85);
    border: 1px solid rgba(255,255,255,.6);
  }
  .archive-card-body { padding: 1rem 1.1rem 1.1rem; }
  .archive-card-title {
    font-size: 1.05rem; font-weight: 500;
    margin-bottom: .4rem;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .archive-card-story {
    font-size: .88rem; color: var(--ink-mid); line-height: 1.55;
    margin-bottom: .65rem;
    display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
    overflow: hidden;
  }
  .archive-card-meta {
    display: flex; flex-direction: column; gap: .25rem;
  }
  .archive-card-meta .mono {
    display: flex; align-items: center; gap: .3rem;
  }
  .archive-card-actions {
    display: flex; gap: .5rem; margin-top: .75rem; padding-top: .75rem;
    border-top: 1px solid var(--rule);
  }
  </style>`)
}
