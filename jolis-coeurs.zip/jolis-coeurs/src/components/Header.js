// src/components/Header.js
import { AppState, navigate, applyTheme } from '../main.js'
import { supabase } from '../lib/supabase.js'

export async function renderHeader() {
  const user    = AppState.user
  const profile = AppState.profile

  const navAuth = user
    ? `<nav class="header-nav" aria-label="Navigation principale">
        <a href="/my-archives" data-link class="nav-link">Mes archives</a>
        <a href="/archives/new" data-link class="btn btn-primary btn-sm">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Ajouter
        </a>
        <a href="/u/${profile?.username || ''}" data-link class="nav-avatar" title="Mon profil" aria-label="Mon profil">
          ${profile?.avatar_url
            ? `<img src="${esc(profile.avatar_url)}" alt="${esc(profile.display_name)}" class="avatar" style="width:34px;height:34px">`
            : `<span class="avatar-placeholder" style="width:34px;height:34px;font-size:.9rem">${(profile?.display_name||'?')[0].toUpperCase()}</span>`
          }
        </a>
        <a href="/settings" data-link class="nav-link hide-mobile" title="Réglages">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
        </a>
        <button id="signout-btn" class="btn btn-ghost btn-sm hide-mobile">Déconnexion</button>
      </nav>`
    : `<nav class="header-nav">
        <a href="/login"  data-link class="btn btn-ghost btn-sm">Se connecter</a>
        <a href="/signup" data-link class="btn btn-primary btn-sm">Créer un compte</a>
      </nav>`

  const html = `
    <header id="site-header" class="site-header">
      <div class="header-inner container">
        <a href="/" data-link class="site-logo" aria-label="Accueil">
          <img src="/logo.svg" alt="" width="36" height="36" aria-hidden="true">
          <span class="site-title">
            <span class="title-main">Jolis ♡ ☆ ☽</span>
            <span class="title-sub">du monde</span>
          </span>
        </a>
        <div class="header-right">
          ${navAuth}
          <div class="theme-switcher" aria-label="Changer le thème">
            <button class="theme-btn ${AppState.theme === 'cream'  ? 'active' : ''}" data-theme="cream"  title="Papier crémeux">☽</button>
            <button class="theme-btn ${AppState.theme === 'sky'    ? 'active' : ''}" data-theme="sky"    title="Ciel pastel">☆</button>
            <button class="theme-btn ${AppState.theme === 'bloom'  ? 'active' : ''}" data-theme="bloom"  title="Fleur pastel">♡</button>
          </div>
        </div>
      </div>
    </header>
  `

  // On retourne le HTML, les events seront attachés après injection
  setTimeout(() => attachHeaderEvents(), 0)
  return html
}

function attachHeaderEvents() {
  // Theme switcher
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const theme = btn.dataset.theme
      applyTheme(theme)
      document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'))
      btn.classList.add('active')
      // Sauvegarder si connecté
      if (AppState.user && AppState.profile) {
        await supabase.from('profiles')
          .update({ theme_preference: theme })
          .eq('id', AppState.user.id)
        AppState.profile.theme_preference = theme
      }
    })
  })

  // Déconnexion
  document.getElementById('signout-btn')?.addEventListener('click', async () => {
    await supabase.auth.signOut()
    AppState.user    = null
    AppState.profile = null
    navigate('/')
  })

  // Links
  document.querySelectorAll('[data-link]').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault()
      const href = el.getAttribute('href')
      if (href) navigate(href)
    })
  })
}

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
}

// CSS header injecté une seule fois
const headerCSS = `
<style id="header-styles">
.site-header {
  position: sticky; top: 0; z-index: 100;
  background: var(--bg-card);
  border-bottom: 1px solid var(--rule);
  backdrop-filter: blur(8px);
}
.header-inner {
  display: flex; align-items: center; justify-content: space-between;
  padding-top: .75rem; padding-bottom: .75rem; gap: 1rem;
}
.site-logo {
  display: flex; align-items: center; gap: .6rem;
  text-decoration: none; color: var(--ink);
  flex-shrink: 0;
}
.site-logo:hover { text-decoration: none; }
.site-title { display: flex; flex-direction: column; line-height: 1.1; }
.title-main {
  font-family: var(--fd); font-size: 1rem; font-weight: 700;
  font-style: italic; color: var(--ink);
  letter-spacing: -.01em;
}
.title-sub {
  font-family: var(--fm); font-size: .62rem; font-weight: 300;
  text-transform: uppercase; letter-spacing: .12em; color: var(--ink-soft);
}
.header-right { display: flex; align-items: center; gap: .75rem; }
.header-nav   { display: flex; align-items: center; gap: .5rem; }
.nav-link {
  font-family: var(--fb); font-size: .9rem; color: var(--ink-mid);
  text-decoration: none; padding: .3rem .5rem; border-radius: 6px;
  transition: background .15s;
}
.nav-link:hover { background: var(--bg-alt); color: var(--ink); text-decoration: none; }
.nav-avatar { display: flex; align-items: center; text-decoration: none; }
.nav-avatar:hover { opacity: .8; }
.theme-switcher {
  display: flex; gap: 2px;
  background: var(--bg-alt); border-radius: 99px;
  padding: 2px; border: 1px solid var(--rule);
}
.theme-btn {
  width: 28px; height: 28px; border-radius: 50%;
  font-size: .9rem; display: flex; align-items: center; justify-content: center;
  cursor: pointer; border: 1px solid transparent;
  transition: all .15s; background: transparent; color: var(--ink-soft);
}
.theme-btn.active, .theme-btn:hover {
  background: var(--surface); border-color: var(--rule);
  color: var(--ink); box-shadow: 0 1px 4px var(--shadow);
}
</style>`

if (!document.getElementById('header-styles')) {
  document.head.insertAdjacentHTML('beforeend', headerCSS)
}
