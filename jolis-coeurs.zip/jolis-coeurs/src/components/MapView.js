// src/components/MapView.js
export function renderMapView(lat, lng, title = '') {
  const id = `map-${Date.now()}`
  setTimeout(() => {
    const el = document.getElementById(id)
    if (!el || typeof L === 'undefined') return
    const map = L.map(id, { zoomControl: true, scrollWheelZoom: false })
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap'
    }).addTo(map)
    map.setView([lat, lng], 15)

    // Marqueur personnalisé
    const icon = L.divIcon({
      className: 'custom-map-marker',
      html: `<span class="map-marker-inner">♡</span>`,
      iconSize: [36, 36],
      iconAnchor: [18, 18],
    })
    L.marker([lat, lng], { icon })
      .bindPopup(`<strong>${title || 'Archive'}</strong><br><small>${lat.toFixed(5)}, ${lng.toFixed(5)}</small>`)
      .addTo(map)
      .openPopup()
  }, 100)

  return `
    <div id="${id}" class="map-view" aria-label="Carte de localisation" role="img"></div>
    <style>
    .map-view { height: 280px; border-radius: var(--radius); overflow: hidden; border: 1px solid var(--rule); }
    .custom-map-marker { background: transparent; border: none; }
    .map-marker-inner {
      display: flex; align-items: center; justify-content: center;
      width: 36px; height: 36px; border-radius: 50%;
      background: var(--accent); color: #fff;
      font-size: 1.1rem;
      box-shadow: 0 2px 8px rgba(0,0,0,.3);
    }
    </style>
  `
}

export function renderMiniMap(lat, lng) {
  const id = `minimap-${Date.now()}`
  setTimeout(() => {
    const el = document.getElementById(id)
    if (!el || typeof L === 'undefined') return
    const map = L.map(id, {
      zoomControl: false, dragging: false,
      scrollWheelZoom: false, doubleClickZoom: false,
      keyboard: false, touchZoom: false
    })
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map)
    map.setView([lat, lng], 13)
    L.circleMarker([lat, lng], { radius: 8, color: 'var(--accent)', fillColor: 'var(--accent)', fillOpacity: .7 }).addTo(map)
  }, 80)
  return `<div id="${id}" style="height:160px;border-radius:var(--radius-sm);overflow:hidden;border:1px solid var(--rule)"></div>`
}
